import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => GameState(),
      child: WordGuessApp(),
    ),
  );
}

class WordGuessApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Show splash screen for 3 seconds before navigating to the game
    Future.delayed(Duration(seconds: 3), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => HangmanGame()),
      );
    });

    return Scaffold(
      body: Center(
        child: Image.asset('assets/splash.jpg'),
      ),
    );
  }
}

class HangmanGame extends StatefulWidget {
  @override
  _HangmanGameState createState() => _HangmanGameState();
}

class _HangmanGameState extends State<HangmanGame> {
  bool _isPaused = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Word Guess',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.black,
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'Replay':
                  _showSplashScreenThenRestart();
                  break;
                case 'Pause':
                  setState(() {
                    _isPaused = true;
                  });
                  break;
                case 'Resume':
                  setState(() {
                    _isPaused = false;
                  });
                  break;
                case 'Quit':
                  _showQuitScreenThenExit();
                  break;
              }
            },
            itemBuilder: (BuildContext context) {
              return {'Replay', 'Pause', 'Resume', 'Quit'}.map((String choice) {
                return PopupMenuItem<String>(
                  value: choice,
                  child: Text(choice),
                );
              }).toList();
            },
          ),
        ],
      ),
      body: _isPaused
          ? Center(child: Image.asset('assets/pause.jpg'))
          : Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/background.jpg',
              fit: BoxFit.cover,
            ),
          ),
          Consumer<GameState>(
            builder: (context, gameState, child) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Question: ${gameState.question}',
                            style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 20),
                          Text(
                            'Wrong guesses: ${gameState.wrongGuesses}/${gameState.maxWrongGuesses}',
                            style: TextStyle(fontSize: 24, color: Colors.black, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _buildWordDisplay(gameState.word, gameState.guessedLetters),
                            style: TextStyle(fontSize: 32, letterSpacing: 4, color: Colors.black, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 20),
                          if (gameState.hasWon)
                            Text(
                              'You WON!',
                              style: TextStyle(fontSize: 28, color: Colors.green, fontWeight: FontWeight.bold),
                            )
                          else if (gameState.hasLost)
                            Column(
                              children: [
                                Text(
                                  'You LOST!',
                                  style: TextStyle(fontSize: 28, color: Colors.red, fontWeight: FontWeight.bold),
                                ),
                                SizedBox(height: 10),
                                Text(
                                  'The correct word was: ${gameState.word}',
                                  style: TextStyle(fontSize: 24, color: Colors.blue, fontWeight: FontWeight.bold),
                                ),
                              ],
                            )
                          else
                            _buildLetterButtons(context),
                          SizedBox(height: 20),
                          ElevatedButton(
                            onPressed: () {
                              _showSplashScreenThenRestart();
                            },
                            child: Text(
                              'Play Again',
                              style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  void _showSplashScreenThenRestart() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => SplashScreen(),
      ),
    );
    Future.delayed(Duration(seconds: 3), () {
      context.read<GameState>().resetGame();
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => HangmanGame(),
        ),
      );
    });
  }

  void _showQuitScreenThenExit() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => QuitScreen(),
      ),
    );
    Future.delayed(Duration(minutes: 2), () {
      SystemNavigator.pop(); // Exits the app
    });
  }

  String _buildWordDisplay(String word, List<String> guessedLetters) {
    return word
        .split('')
        .map((letter) => guessedLetters.contains(letter) ? letter : '_')
        .join(' ');
  }

  Widget _buildLetterButtons(BuildContext context) {
    final rows = [
      'QWERTYUIOP',
      'ASDFGHJKL',
      'ZXCVBNM'
    ];

    return Column(
      children: rows.map((row) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: row.split('').map((letter) {
            return Padding(
              padding: const EdgeInsets.all(4.0), // Space between keys
              child: ElevatedButton(
                onPressed: () {
                  context.read<GameState>().guessLetter(letter);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  fixedSize: Size(40, 40),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8), // Rounded corners
                  ),
                ),
                child: Text(
                  letter,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            );
          }).toList(),
        );
      }).toList(),
    );
  }
}

class QuitScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset('assets/quit.jpg'),
      ),
    );
  }
}

class GameState with ChangeNotifier {
  final List<Map<String, String>> _wordBank = [
    {'question': 'A yellow fruit that monkeys love', 'word': 'BANANA'},
    {'question': 'A large body of saltwater', 'word': 'OCEAN'},
    {'question': 'A flying mammal', 'word': 'BAT'},
    {'question': 'A device used to talk to someone far away', 'word': 'PHONE'},
    {'question': 'A sweet red or green fruit', 'word': 'APPLE'},
    {'question': 'The process of cooking food with dry heat', 'word': 'BAKING'},
    {'question': 'A domesticated carnivorous mammal', 'word': 'DOG'},
    {'question': 'A large animal with a trunk', 'word': 'ELEPHANT'},
    {'question': 'A popular tropical fruit with a spiky skin', 'word': 'PINEAPPLE'},
    {'question': 'A city known for its Eiffel Tower', 'word': 'PARIS'},
  ];
  String _question = '';
  String _word = '';
  List<String> _guessedLetters = [];
  int _wrongGuesses = 0;
  int _maxWrongGuesses = 6;

  GameState() {
    _startNewGame();
  }

  String get question => _question;
  String get word => _word;
  List<String> get guessedLetters => _guessedLetters;
  int get wrongGuesses => _wrongGuesses;
  int get maxWrongGuesses => _maxWrongGuesses;
  bool get hasWon => _word.split('').every((letter) => _guessedLetters.contains(letter));
  bool get hasLost => _wrongGuesses >= _maxWrongGuesses;

  void _startNewGame() {
    final randomIndex = (DateTime.now().millisecondsSinceEpoch ~/ 1000) % _wordBank.length;
    _question = _wordBank[randomIndex]['question']!;
    _word = _wordBank[randomIndex]['word']!;
    _guessedLetters.clear();
    _wrongGuesses = 0;
    notifyListeners();
  }

  void guessLetter(String letter) {
    if (_guessedLetters.contains(letter) || hasWon || hasLost) return;

    _guessedLetters.add(letter);

    if (!_word.contains(letter)) {
      _wrongGuesses++;
    }

    notifyListeners();
  }

  void resetGame() {
    _startNewGame();
  }
}

